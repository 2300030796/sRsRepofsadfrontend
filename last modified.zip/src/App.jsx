import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import MainNavBar from './main/MainNavbar';
import AdminLogin from './admin/AdminLogin';
import AdminMenuBar from './admin/AdminMenuBar';

export default function App() {
  return (
    <div className='content'>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<MainNavBar />} />
          <Route path="/adminmenu/*" element={<AdminMenuBar />} />
          <Route path="/adminlogin" element={<AdminLogin />} />
          {/* <Route path='/faclogin' Component={FacultyLogin}/> */}
        </Routes>
      </BrowserRouter>
    </div>
  );
}