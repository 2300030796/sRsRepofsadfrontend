import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; 
import axios from 'axios';
import './admin.css';

export default function AdminLogin() {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    captchaInput: ''
  });

  const [captcha, setCaptcha] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const navigate = useNavigate();
  const generateCaptcha = () => {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < 5; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setCaptcha(result);
  };

  // Generate captcha when component mounts
  useEffect(() => {
    generateCaptcha();
  }, []);

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (formData.captchaInput !== captcha) {
      setError("Captcha does not match.");
      generateCaptcha(); // refresh captcha
      return;
    }

    try {
      const response = await axios.post("http://localhost:2005/adminlogin", {
        username: formData.username,
        password: formData.password
      });

      if (response.status === 200) {
        setMessage("Login successful!");
        navigate("/adminmenu");
      }
    } catch (err) {
      if (err.response && err.response.status === 401) {
        setError("Invalid username or password.");
      } else {
        setError("An unexpected error occurred.");
      }
      generateCaptcha(); // refresh captcha after attempt
    }
  };

  return (
    <div className="login-container">
      <h3 className="login-title">Admin Login</h3>

      {message && <p className="success-message">{message}</p>}
      {error && <p className="error-message">{error}</p>}

      <form onSubmit={handleSubmit} className="login-form">
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            value={formData.username}
            onChange={handleChange}
            required
            className="form-input"
          />
        </div>

        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={formData.password}
            onChange={handleChange}
            required
            className="form-input"
          />
        </div>

        <div className="form-group">
          <label>Captcha</label>
          <div className="captcha-box">
            <span className="captcha-text">{captcha}</span>
            <button type="button" onClick={generateCaptcha} className="refresh-button">↻</button>
          </div>
          <input
            type="text"
            id="captchaInput"
            value={formData.captchaInput}
            onChange={handleChange}
            required
            className="form-input"
            placeholder="Enter captcha"
          />
        </div>

        <button type="submit" className="button">Login</button>
      </form>
    </div>
  );
}
