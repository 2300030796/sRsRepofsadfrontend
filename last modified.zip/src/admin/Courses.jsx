import React, { useState, useEffect } from 'react';
import './faculty.css';

export default function AddCourse() {
  const [courseId, setCourseId] = useState("");
  const [courseName, setCourseName] = useState("");
  const [credits, setCredits] = useState("");
  const [semester, setSemester] = useState("");
  const [department, setDepartment] = useState("");
  const [facultyId, setFacultyId] = useState("");
  const [facultyName, setFacultyName] = useState("");

  const [facultyList, setFacultyList] = useState([
    { id: 1, name: "Faculty 1" },
    { id: 2, name: "Faculty 2" },
    { id: 3, name: "Faculty 3" }
  ]);

  useEffect(() => {
    const selected = facultyList.find(f => f.id.toString() === facultyId);
    setFacultyName(selected ? selected.name : "");
  }, [facultyId, facultyList]);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!courseId || !courseName || !credits || !semester || !department || !facultyId) {
      alert("Please fill in all required fields.");
      return;
    }

    alert("Course added successfully!");

    setCourseId("");
    setCourseName("");
    setCredits("");
    setSemester("");
    setDepartment("");
    setFacultyId("");
    setFacultyName("");
  };

  return (
    <div className='faculty-box'>
      <h2 style={{ textAlign: 'center', fontFamily: 'Montserrat, sans-serif', color: 'black', marginBottom: '30px', textShadow: '0 0 2px white, 0 0 4px rgba(255,255,255,0.5)' }}>Add New Course</h2>
      <form className='form-fields' onSubmit={handleSubmit}>
        <div className='form-row'>
          <label>Course ID</label>
          <input type="text" value={courseId} onChange={(e) => setCourseId(e.target.value)} required />
        </div>

        <div className='form-row'>
          <label>Course Name</label>
          <input type="text" value={courseName} onChange={(e) => setCourseName(e.target.value)} required />
        </div>

        <div className='form-row'>
          <label>Credits</label>
          <input type="number" value={credits} onChange={(e) => setCredits(e.target.value)} required />
        </div>

        <div className='form-row'>
          <label>Semester</label>
          <select value={semester} onChange={(e) => setSemester(e.target.value)} required>
            <option value="">Select Semester</option>
            <option value="Odd">Odd</option>
            <option value="Even">Even</option>
          </select>
        </div>

        <div className='form-row'>
          <label>Department</label>
          <select value={department} onChange={(e) => setDepartment(e.target.value)} required>
            <option value="">Select Department</option>
            <option value="CSE">CSE</option>
            <option value="ECE">ECE</option>
            <option value="AIDS">AIDS</option>
            <option value="IOT">IOT</option>
          </select>
        </div>

        <div className='form-row'>
          <label>Faculty ID</label>
          <select value={facultyId} onChange={(e) => setFacultyId(e.target.value)} required>
            <option value="">Select Faculty</option>
            {facultyList.map(f => (
              <option key={f.id} value={f.id}>{f.id} - {f.name}</option>
            ))}
          </select>
        </div>

        <div className='form-row'>
          <label>Faculty Name</label>
          <input type="text" value={facultyName} readOnly />
        </div>

        <button type="submit" className='faculty-button'>Add Course</button>
      </form>
    </div>
  );
}
