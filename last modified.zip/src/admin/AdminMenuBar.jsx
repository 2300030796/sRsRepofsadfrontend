import React from 'react';
import { Link, Route, Routes } from 'react-router-dom';
import Home from './Home';
import FeeStructure from './FeeStructure';
import './style.css';
import Department from './Department';
import Courses from './Courses';
import ScheduleExamDates from './ScheduleExams';
import Results from './Results';
import { FaHome, FaUser, FaGraduationCap, FaBook, FaDollarSign, FaCalendarAlt, FaChartBar } from 'react-icons/fa';
import { GiProgression } from "react-icons/gi";
import AdminLogin from './AdminLogin';
import ViewFaculty from './ViewFaculty';
import AddFaculty from './AddFaculty';
import AddStudent from './AddStudent';
import { useAuth } from '../contextapi/AuthContext';

export default function AdminMenuBar() 
{
  return (
    <div>
      <div className='bgimage'></div>
      <div className='admin-dashboard'>
        <nav className='admin-nav'>
          <ul className='adminmenubar'>
            <div className='heading'><GiProgression /> Progress Path</div>
            <li><Link to="/adminmenu/adminhome" className='admin-link'><FaHome /> Home</Link></li>
            <li><Link to="/adminmenu/addfaculty" className='admin-link'><FaUser /> Add Faculty</Link></li>
            <li><Link to="/adminmenu/viewallfaculty" className='admin-link'><FaUser /> View Faculty</Link></li>
            <li><Link to="/adminmenu/addstudent" className='admin-link'><FaGraduationCap /> Add Student</Link></li>
            <li><Link to="/adminmenu/courses" className='admin-link'><FaBook /> Courses</Link></li>
            <li><Link to="/adminmenu/feestructure" className='admin-link'><FaDollarSign /> Fee Structure</Link></li>
            <li><Link to="/adminmenu/scheduleexams" className='admin-link'><FaCalendarAlt /> Schedule Exams</Link></li>
            <li><Link to="/adminmenu/results" className='admin-link'><FaChartBar /> Results</Link></li>
          {/* <li><Link to="/adminlogin" onClick={handleLogout}>Logout</Link></li>  */}
          </ul>
        </nav>
        <div className='admin-data'>
          <Routes>
            <Route path="adminhome" element={<Home />} />
            <Route path="addfaculty" element={<AddFaculty />} />
            <Route path="viewallfaculty" element={<ViewFaculty />} />
            <Route path="department" element={<Department />} />
            <Route path="addstudent" element={<AddStudent />} />
            <Route path="courses" element={<Courses />} />
            <Route path="feestructure" element={<FeeStructure />} />
            <Route path="scheduleexams" element={<ScheduleExamDates />} />
            <Route path="results" element={<Results />} />
            <Route path="login" element={<AdminLogin />} />
          </Routes>
        </div>
      </div>
    </div>
  );
}