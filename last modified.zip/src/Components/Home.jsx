import React from 'react'

export default function Home() {
  return (
    <div>
      <h3>Home</h3>
    </div>
  )
}
