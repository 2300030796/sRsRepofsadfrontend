import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function FacultyLogin() {
  const [formData, setFormData] = useState({
    username: '',
    password: ''
  });
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData({ ...formData, [id]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:5000/faclogin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(formData)
      });

      const data = await response.json();

      if (response.ok) {
        // Save full faculty details to localStorage if needed
        localStorage.setItem("isFacultyLoggedIn", "true");
        localStorage.setItem("facultyId", data.id);        // optional
        localStorage.setItem("facultyName", data.name);    // optional
        localStorage.setItem("facultyUsername", data.username); // optional

        setMessage("Login successful!");
        setError("");
        navigate("/facultyhome");
      } else {
        setMessage('');
        setError(data || "Login failed.");
      }
    } catch (err) {
      setError("An unexpected error occurred.");
    }
  };

  return (
    <div className="login-container">
      <h3 className="login-title">Faculty Login</h3>
      {
        message ? 
          <p className="success-message">{message}</p> : 
          <p className="error-message">{error}</p>
      }
      <form onSubmit={handleSubmit} className="login-form">
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            value={formData.username}
            onChange={handleChange}
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={formData.password}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit" className="login-button" onClick={()=>{
          
        }}>Login</button>
      </form>
    </div>
  );
}
