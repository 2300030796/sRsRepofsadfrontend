import React from 'react'

export default function StudentRegistration() {
  return (
    <div>StudentRegistration</div>
  )
}
