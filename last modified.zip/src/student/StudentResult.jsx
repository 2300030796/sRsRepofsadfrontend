import React from 'react'

export default function StudentResult() {
  return (
    <div>StudentResult</div>
  )
}
