import React from 'react'

export default function StudentHome() {
  return (
    <div>StudentHome</div>
  )
}
