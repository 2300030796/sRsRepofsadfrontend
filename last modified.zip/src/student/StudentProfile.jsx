import React from 'react'

export default function StudentProfile() {
  return (
    <div>StudentProfile</div>
  )
}
