import React from 'react'

export default function StudentFeePayment() {
  return (
    <div>StudentFeePayment</div>
  )
}
