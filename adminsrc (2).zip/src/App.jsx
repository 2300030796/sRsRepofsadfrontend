import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider, useAuth } from "./contextapi/AuthContext";
  // Assuming you meant FacultyNavBar
// import StudentNavBar from './student/StudentNavBar';  // Commented out as per your request
import AdminLogin from './admin/AdminLogin';

import MainNavBar from './main/MainNavbar';
import Navbar from './Components/Navbar';


function AppContent() {
  const { isAdminLoggedIn, isStudentLoggedIn, isFacultyLoggedIn } = useAuth();

  return (
    <div>
      <BrowserRouter>
        {isAdminLoggedIn ? (
          <AdminNavBar />
        ) : isStudentLoggedIn ? (
          <StudentNavBar/>
        ) : isFacultyLoggedIn ? (
          <Navbar />
        ) : (
          <MainNavBar />
        )}
        <Routes>
          {/* Define routes here */}
          <Route path="/adminlogin" element={<AdminLogin />} />
          <Route path="/faclogin" element={<FacultyLogin />} />
          {/* Add more routes as needed */}
        </Routes>
      </BrowserRouter>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;

