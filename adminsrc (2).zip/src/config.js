const config = 
{
    "url":"http://localhost:2005"
}

export default config