import React, { useState } from 'react';
import { Link, Route, Routes } from 'react-router-dom';
import {
  FaHome, FaUser, FaBuilding, FaGraduationCap, FaBook,
  FaDollarSign, FaCalendarAlt, FaCaretDown
} from 'react-icons/fa';
import { GiProgression } from "react-icons/gi";


import './Navbar.css';
import Attendance from './src/faculty/Attendance';
import Evaluation from './src/faculty/Evaluation';
import FacultyStudentInfo from './src/faculty/StudentInfo';
import FacultyTimeTable from './src/faculty/FacultyTimetable';
import FacultyProfile from './src/faculty/FacultyProfile';
import FacultyLogin from './src/faculty/FacultyLogin';
import FacultyReports from './src/faculty/Reports';
i


export default function Navbar() {
  const [activeDropdown, setActiveDropdown] = useState(null);

  const toggleDropdown = (menu) => {
    setActiveDropdown(activeDropdown === menu ? null : menu);
  };

  return (
    <div>
      <div className='bgimage'></div>
      <div className='Faculty-Dashboard'>
        <nav className='Faculty-nav'>
          <ul className='Facultymenubar'>
            <div className='heading'><GiProgression /> Progress path</div>
            <li><Link to="/" className='Faculty-link'><FaHome /> Home </Link></li>

            {/* Attendance Dropdown */}
            <li className="dropdown-container">
              <div className='Faculty-link dropdown-toggle' onClick={() => toggleDropdown('attendance')}>
                <FaUser /> Attendance <FaCaretDown />
              </div>
              {activeDropdown === 'attendance' && (
                <ul className="dropdown-menu">
                  <li><Link to="Attendance" className='dropdown-item'>Mark Attendance</Link></li>
                 
                </ul>
              )}
            </li>

            {/* Evaluation Dropdown */}
            <li className="dropdown-container">
              <div className='Faculty-link dropdown-toggle' onClick={() => toggleDropdown('evaluation')}>
                <FaBuilding /> Evaluation <FaCaretDown />
              </div>
              {activeDropdown === 'evaluation' && (
                <ul className="dropdown-menu">
                  
                  <li><Link to="/Evaluation" className='dropdown-item'>Grade Reports</Link></li>
                </ul>
              )}
            </li>

            
            <li><Link to="/StudentInfo" className='Faculty-link'><FaBook /> Student Info</Link></li>
            <li><Link to="/Profile" className='Faculty-link'><FaDollarSign /> Profile</Link></li>
            <li><Link to="/TimeTable" className='Faculty-link'><FaCalendarAlt /> FacultyTimetable</Link></li>
            <li><Link to="/Reports" className='Faculty-link'><FaGraduationCap /> Reports</Link></li>
            <li><Link to="/Facultylogin" className='Faculty-link'>Login</Link></li>
          </ul>
        </nav>

        <div className='Faculty-data'>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/Attendance" element={<Attendance />} />
           
            <Route path="/Evaluation" element={<Evaluation />} />
            <Route path="/Reports" element={<FacultyReportsReport />} />
            <Route path="/StudentInfo" element={<FacultyStudentInfo/>} />
            <Route path="/FacultyTimeTable" element={<FacultyTimeTable />} />
            <Route path="/Profile" element={<FacultyProfile />} />
            <Route path="/Facultylogin" element={<FacultyLogin />} />
            <Route path="*" element={<div style={{ padding: 20, textAlign: 'center' }}>Page Not Found</div>} />
          </Routes>
        </div>
      </div>
    </div>
  );
}
