import React, { useEffect, useState } from "react";
import axios from "axios";


const FacultyReports = ({ facultyId }) => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const response = await axios.get(`/api/faculty/${facultyId}/reports`);
        setReports(response.data);
        setLoading(false);
      } catch (err) {
        setError("Failed to fetch reports.");
        setLoading(false);
      }
    };

    fetchReports();
  }, [facultyId]);

  if (loading) return <p>Loading reports...</p>;
  if (error) return <p>{error}</p>;

  return (
    <div className="report-container">
      <h2 className="report-title">Student Reports</h2>
      <table className="report-table">
        <thead>
          <tr>
            <th>Student ID</th>
            <th>Name</th>
            <th>Subject</th>
            <th>Internal</th>
            <th>External</th>
            <th>Attendance (%)</th>
            <th>Remarks</th>
          </tr>
        </thead>
        <tbody>
          {reports.map((report, index) => (
            <tr key={index}>
              <td>{report.student_id}</td>
              <td>{report.name}</td>
              <td>{report.subject}</td>
              <td>{report.internal_marks}</td>
              <td>{report.external_marks}</td>
              <td>{report.attendance}</td>
              <td>{report.remarks}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default FacultyReports;
