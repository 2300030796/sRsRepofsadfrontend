import React, { useState } from 'react';
import './faculty.css'; 

export default function AddStudent() {
  const [studentName, setStudentName] = useState("");
  const [course, setCourse] = useState("");
  const [department, setDepartment] = useState("");
  const [gender, setGender] = useState("");
  const [contact, setContact] = useState("");
  const [dob, setDob] = useState("");
  const [password, setPassword] = useState("");

  const addStudent = (e) => {
    e.preventDefault();
    if (studentName.length==0 || course.length==0 || department.length==0 || gender.length==0 || contact.length==0 || dob.length==0 || password==0) {
      alert("Please fill all the fields!");
      return;
    }
    alert(`Student Added: ${studentName}`);
    setStudentName("");
    setCourse("");
    setDepartment("");
    setGender("");
    setContact("");
    setDob("");
    setPassword("");
  };

  return (
    <div className='faculty-box'>
      <h2 style={{ textAlign: 'center', fontFamily: 'Montserrat, sans-serif', color: 'black', marginBottom: '30px', textShadow: '0 0 2px white, 0 0 4px rgba(255,255,255,0.5)' }}>
        Add New Student
      </h2>
      <form className="form-fields" onSubmit={addStudent}>
        <div className="form-row">
          <label className='label'>Student Name</label>
          <input type="text" value={studentName} onChange={(e) => setStudentName(e.target.value)} />
        </div>

        <div className="form-row">
          <label>Department</label>
          <select value={department} onChange={(e) => setDepartment(e.target.value)}>
            <option value="">Select Department</option>
            <option value="CSE">CSE</option>
            <option value="ECE">ECE</option>
            <option value="AIDS">AIDS</option>
            <option value="IOT">IOT</option>
          </select>
        </div>

        <div className="form-row">
          <label>Course</label>
          <select value={course} onChange={(e) => setCourse(e.target.value)}>
            <option value="">Select Course</option>
            <option value="FSAD">FSAD</option>
            <option value="Data Structures">Data Structures</option>
            <option value="Embedded System">Embedded System</option>
            <option value="Machine Learning">Machine Learning</option>
            <option value="Operating Systems">Operating Systems</option>
          </select>
        </div>

        <div className="form-row">
          <label>Gender</label>
          <select value={gender} onChange={(e) => setGender(e.target.value)}>
            <option value="">Select Gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>

        <div className="form-row">
          <label>Contact</label>
          <input type="text" value={contact} onChange={(e) => setContact(e.target.value)} />
        </div>

        <div className="form-row">
          <label>Date of Birth</label>
          <input type="date" value={dob} onChange={(e) => setDob(e.target.value)} />
        </div>

        <div className="form-row">
          <label>Password</label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>

        <button type="submit" className='faculty-button'>Add Student</button>
      </form>
    </div>
  );
}
