import React from 'react'

export default function ExamSection() {
  return (
    <div>
      <h3><u>iam in examsection</u></h3>
    </div>
  )
}
