import React from 'react'

export default function ViewFaculty() {
  return (
    <div>ViewFaculty</div>
  )
}
